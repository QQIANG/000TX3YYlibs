//
//  CentTests.swift
//  CentTests
//
//  Created by Ankur Patel on 6/28/14.
//  Copyright (c) 2014 Encore Dev Labs LLC. All rights reserved.
//

import XCTest
import Cent

class CentTests: XCTestCase {

}
