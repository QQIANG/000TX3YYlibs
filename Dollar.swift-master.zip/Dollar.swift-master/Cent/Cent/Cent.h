//
//  Cent.h
//  Cent
//
//  Created by Ankur Patel on 6/28/14.
//  Copyright (c) 2014 Encore Dev Labs LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Cent.
FOUNDATION_EXPORT double CentVersionNumber;

//! Project version string for Cent.
FOUNDATION_EXPORT const unsigned char CentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Cent/PublicHeader.h>


