//
//  Range.swift
//  Cent
//
//  Created by Ankur Patel on 6/30/14.
//  Copyright (c) 2014 Encore Dev Labs LLC. All rights reserved.
//

import Foundation
import Dollar

extension Range {
    
    /// For each index in the range invoke the callback by passing the item in range
    ///
    /// :param callback The callback function to invoke that take an element
    public func eachWithIndex(callback: (T) -> ()) {
        for index in self {
            callback(index)
        }
    }

    /// For each index in the range invoke the callback
    ///
    /// :param callback The callback function to invoke
    public func each(callback: () -> ()) {
        self.eachWithIndex { (T) -> () in
            callback()
        }
    }
    
}

func ==<T: ForwardIndexType>(left: Range<T>, right: Range<T>) -> Bool {
    return left.startIndex == right.startIndex && left.endIndex == right.endIndex
}
