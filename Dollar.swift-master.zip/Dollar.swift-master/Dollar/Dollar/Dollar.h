//
//  Dollar.h
//  Dollar
//
//  Created by Ankur Patel on 6/9/14.
//  Copyright (c) 2014 Encore Dev Labs LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Dollar.
FOUNDATION_EXPORT double DollarVersionNumber;

//! Project version string for Dollar.
FOUNDATION_EXPORT const unsigned char DollarVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Dollar/PublicHeader.h>


