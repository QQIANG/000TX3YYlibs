//
//  CarExample.swift
//  Dollar
//
//  Created by Tiago Bastos on 6/11/14.
//  Copyright (c) 2014 Encore Dev Labs LLC. All rights reserved.
//

import Foundation

class CarExample {
    var name:String?
    var color:String?
    
    init(name: String) {
        self.name = name
    }
}
