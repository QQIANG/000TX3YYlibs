//
//  SKControl.h
//  封装
//
//  Created by silverk on 14-7-17.
//  Copyright (c) 2014年 silverk. All rights reserved.
//
//类方法创建UILabel，UIButton，UIImageView
#import <Foundation/Foundation.h>

@interface SKControl : NSObject
//判断版本
+(CGFloat)isIOS7;

//创建label
+(UILabel*)createLabelWithFrame:(CGRect)frame FontSize:(float)fontSize Text:(NSString*)text TextAlignment:(NSTextAlignment)textAlignment;

//创建button
+(UIButton*)createButtonWithFrame:(CGRect)frame ContentImageName:(NSString*)ContentImageName BgImageName:(NSString*)BgImageName Title:(NSString*)title SEL:(SEL)selector Target:(id)target;

//创建imageView
+(UIImageView*)createImageViewWithFrame:(CGRect)frame ImageName:(NSString*)imageName;
//定制Nav
+(UIImageView*)createCustomNavBarWithBgImageName:(NSString*)BgImageName LogoName:(NSString*)logoName Title:(NSString*)titleName LeftBackBtn:(UIButton*)leftButton RightBtn:(UIButton*)rightButton;
@end
