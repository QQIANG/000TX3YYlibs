//
//  SKControl.m
//  封装
//
//  Created by silverk on 14-7-17.
//  Copyright (c) 2014年 silverk. All rights reserved.
//

#import "SKControl.h"

@implementation SKControl

//判断版本
+(CGFloat)isIOS7
{
    if ([[[UIDevice currentDevice]systemVersion]floatValue]>=7.0) {
        return 64;
    }else
    {
        return 44;
    }

}

//创建label
+(UILabel*)createLabelWithFrame:(CGRect)frame FontSize:(float)fontSize Text:(NSString*)text TextAlignment:(NSTextAlignment)textAlignment;
{
    UILabel *label = [[UILabel alloc]initWithFrame:frame];
   //设置文字
    if (text) {
        label.text = text;
    }
   //设置字体大小
    label.font = [UIFont systemFontOfSize:fontSize];
   //设置对齐方式
    label.textAlignment = textAlignment;
    //设置行数
    label.numberOfLines = 0;
    //按单词折行
    label.lineBreakMode = NSLineBreakByWordWrapping;
    //设置阴影颜色
    //label.shadowColor = [UIColor yellowColor];
    //设置偏移量
    label.shadowOffset = CGSizeMake(2, 2);
    //不开启交互
    label.userInteractionEnabled = NO;
    //不高亮
    label.highlighted = NO;
    //高亮颜色
    label.highlightedTextColor = nil;
    
    label.textColor = [UIColor blueColor];
    
    //下列方法因情况而在外定义
    //BOOL adjustsFontSizeToFitWidth;         // default is NO
    // adjustsLetterSpacingToFitWidth
    
    return label;
}

//创建button
+(UIButton*)createButtonWithFrame:(CGRect)frame ContentImageName:(NSString*)ContentImageName BgImageName:(NSString*)BgImageName Title:(NSString*)title SEL:(SEL)selector Target:(id)target;
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    //设置框架
    [button setFrame:frame];
    //设置内容图片
    if (ContentImageName) {
        [button setImage:[UIImage imageNamed:ContentImageName] forState:UIControlStateNormal];
    }
    //设置背景图片
    if (BgImageName) {
        [button setBackgroundImage:[UIImage imageNamed:BgImageName] forState:UIControlStateNormal];
    }
    //设置标题
    if (title) {
        [button setTitle:title forState:UIControlStateNormal];
        //设置标题颜色 黑色
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    //设置点击方法
    [button addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
    //设置点击高亮
    button.showsTouchWhenHighlighted = YES;
    return button;
}

//创建imageView
+(UIImageView*)createImageViewWithFrame:(CGRect)frame ImageName:(NSString*)imageName
{
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:frame];
    imageView.image = [UIImage imageNamed:imageName];
    //开启交互
    imageView.userInteractionEnabled = NO;
    return imageView;

}
//定制Nav
+(UIImageView*)createCustomNavBarWithBgImageName:(NSString*)BgImageName LogoName:(NSString*)logoName Title:(NSString*)titleName LeftBackBtn:(UIButton*)leftButton RightBtn:(UIButton*)rightButton
{
    
    //设置frame
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 20, 320, 44)];
    imageView.userInteractionEnabled = YES;
    
    if (BgImageName) {
        [imageView setImage:[UIImage imageNamed:BgImageName]];
    }
    
    //设置title
    if (titleName) {
        UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(110, 5, 100, 34)];
        titleLabel.text = titleName;
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.textColor = [UIColor whiteColor];
        titleLabel.font = [UIFont systemFontOfSize:20];
        titleLabel.userInteractionEnabled = NO;
        titleLabel.backgroundColor = [UIColor clearColor];
        [imageView addSubview:titleLabel];
    }
    
    //设置logo
    
    if (logoName) {
        UIImageView *logoimageView = [[UIImageView alloc]init];
        logoimageView.frame =CGRectMake(110, 5, 100, 34);
        logoimageView.image = [UIImage imageNamed:logoName];
        logoimageView.backgroundColor = [UIColor clearColor];
        [imageView addSubview:logoimageView];
    }
    
    if (leftButton) {
        leftButton.frame = CGRectMake(5, 5, 44, 34);
        [imageView addSubview:leftButton];
    }
    
    if (rightButton) {
        rightButton.frame = CGRectMake(320-5-44, 5, 44, 34);
        [imageView addSubview:rightButton];
    }
    return imageView;
}

@end
