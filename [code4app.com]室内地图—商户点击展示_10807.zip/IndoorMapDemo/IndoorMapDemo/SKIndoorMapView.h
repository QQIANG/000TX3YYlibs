//
//  SKIndoorMapView.h
//  IndoorMapDemo
//
//  Created by silverk on 14-8-3.
//  Copyright (c) 2014年 silverk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PopoverView.h"

@interface SKIndoorMapView : UIScrollView<UIScrollViewDelegate,PopoverViewDelegate>

@property(nonatomic,strong)UIImageView *mapView;

-(id)initWithIndoorMapImageName:(NSString*)indoorMap Frame:(CGRect)frame;
@end
