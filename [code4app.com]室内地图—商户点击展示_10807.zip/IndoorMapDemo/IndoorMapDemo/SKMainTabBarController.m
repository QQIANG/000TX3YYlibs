//
//  SKMainTabBarController.m
//  IndoorMapDemo
//
//  Created by silverk on 14-8-3.
//  Copyright (c) 2014年 silverk. All rights reserved.
//

#import "SKMainTabBarController.h"
#import "SKDetailViewController.h"
#import "SKFloorViewController.h"
#import "SKInformationViewController.h"
#import "SKRetailViewController.h"
#import "SKWeiboViewController.h"

@interface SKMainTabBarController ()

@end

@implementation SKMainTabBarController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        [self createTabBarItem];
        [self createTabBarItemImage];
    }
    return self;
}

-(void)createTabBarItemImage
{
    NSArray *imageArray = @[@"tab_floor",@"tab_store",@"tab_square",@"tab_info",@"tab_detail"];
    
    for (int i=0; i<self.tabBar.items.count; i++) {
        UITabBarItem *item = self.tabBar.items[i];
            UIImage *image = [UIImage imageNamed:imageArray[i]];
            image=[image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
            item.image = image;
        
    }


}

-(void)createTabBarItem
{
    SKFloorViewController *vc1 = [[SKFloorViewController alloc]init];
    vc1.title = @"楼层";
    
    SKRetailViewController *vc2 = [[SKRetailViewController alloc]init];
    vc2.title = @"商户";

    SKWeiboViewController *vc3 = [[SKWeiboViewController alloc]init];
    vc3.title = @"微博";

    SKInformationViewController *vc4 = [[SKInformationViewController alloc]init];
    vc4.title = @"信息";

    
    SKDetailViewController *vc5 = [[SKDetailViewController alloc]init];
    vc5.title = @"详情";
    
    self.viewControllers = @[vc1,vc2,vc3,vc4,vc5];
    
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
