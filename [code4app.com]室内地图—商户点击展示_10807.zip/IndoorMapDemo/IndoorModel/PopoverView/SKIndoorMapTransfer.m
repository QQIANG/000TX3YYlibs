//
//  SKIndoorMapTransfer.m
//  IndoorMapDemo
//
//  Created by silverk on 14-8-7.
//  Copyright (c) 2014年 silverk. All rights reserved.
//

#import "SKIndoorMapTransfer.h"


@implementation SKIndoorMapTransfer

+(void)initWithCoordinate:(NSString*)inStrCoordinate InPoint:(CGPoint)point Inview:(UIView*)view WithTitle:(NSString*)title delegate:(id<PopoverViewDelegate>)delegate
{

    MapArea*_mapArea= [[MapArea alloc]initWithCoordinate:inStrCoordinate];
    if ([_mapArea isAreaSelected:point]) {
        
        [PopoverView showPopoverAtPoint:point inView:view withText:title delegate:delegate];
    }

}

@end
