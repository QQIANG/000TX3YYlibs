//
//  SKWeiboViewController.m
//  IndoorMapDemo
//
//  Created by silverk on 14-8-3.
//  Copyright (c) 2014年 silverk. All rights reserved.
//

#import "SKWeiboViewController.h"

@interface SKWeiboViewController ()<UIWebViewDelegate>
{
    UIActivityIndicatorView *activity;
}
@end

@implementation SKWeiboViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createWebView];
   

}

-(void)createWebView
{
    UIWebView *webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 64, 320, self.view.frame.size.height-64-44)];
    webView.backgroundColor = [UIColor grayColor];
    webView.tintColor = [UIColor darkGrayColor];
    [self.view addSubview:webView];
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.weibo.com"]]];
    webView.delegate=self;
    
    activity = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:(UIActivityIndicatorViewStyleWhiteLarge)];
    activity.hidesWhenStopped = YES;
    
    [webView addSubview:activity];

}

#pragma mark -webView delegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    return YES;
}
//开始加载时调用此方法
- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [activity startAnimating];
}
//加载完成时，调用此方法
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    if ([activity isAnimating]) {
        [activity stopAnimating];
    }    }
//加载出错时，调用此方法
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    if ([activity isAnimating]) {
        [activity stopAnimating];
    }
   
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
