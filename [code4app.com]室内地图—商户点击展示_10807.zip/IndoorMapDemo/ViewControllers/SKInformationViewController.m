//
//  SKInformationViewController.m
//  IndoorMapDemo
//
//  Created by silverk on 14-8-3.
//  Copyright (c) 2014年 silverk. All rights reserved.
//

#import "SKInformationViewController.h"

@interface SKInformationViewController ()

@end

@implementation SKInformationViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UILabel *informationLabel = [SKControl createLabelWithFrame:CGRectMake(20, 80, 200, 30) FontSize:20 Text:@"暂无信息..." TextAlignment:(NSTextAlignmentLeft)];
    [self.view addSubview:informationLabel];
    

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
