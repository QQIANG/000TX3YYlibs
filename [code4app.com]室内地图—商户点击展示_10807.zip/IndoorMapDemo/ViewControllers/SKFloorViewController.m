//
//  SKFloorViewController.m
//  IndoorMapDemo
//
//  Created by silverk on 14-8-3.
//  Copyright (c) 2014年 silverk. All rights reserved.
//

#import "SKFloorViewController.h"
#import "SKIndoorMapView.h"

@interface SKFloorViewController ()

@end

@implementation SKFloorViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    SKIndoorMapView *indoorView = [[SKIndoorMapView alloc]initWithIndoorMapImageName:@"F1.jpeg" Frame:CGRectMake(0, 64, 320, self.view.frame.size.height-64-44) ];

    [self.view addSubview:indoorView];
    
    //[self chooseFloor];
    
    
}

-(void)chooseFloor
{
    //flSwitch_Float底图 flSwitch_confirm下标图 flSwitch_bar_bg设定图
    //先将图显示出来
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 64, self.view.frame.size.width, 94+38)];
    view.backgroundColor = [UIColor clearColor];
    
    UIImageView *bgImageView = [SKControl createImageViewWithFrame:CGRectMake(0, 0, view.frame.size.width, 94) ImageName:@"flSwitch_Float"];
    UILabel *titleLable = [SKControl createLabelWithFrame:CGRectMake((view.frame.size.width-100)/2.0, 5, 100, 40) FontSize:20 Text:@"预设" TextAlignment:(NSTextAlignmentCenter)];
   //chooseview上加scrollView
    UIImageView *chooseImageView = [SKControl createImageViewWithFrame:CGRectMake((view.frame.size.width-308)/2.0, 45, 308, 39) ImageName:@"flSwitch_bar_bg"];
    [bgImageView addSubview:titleLable];
    [bgImageView addSubview:chooseImageView];
    UIImageView *bottomImageView = [SKControl createImageViewWithFrame:CGRectMake((view.frame.size.width-62)/2.0, 94, 62, 38) ImageName:@"flSwitch_confirm"];
    [view addSubview:bgImageView];
    [view addSubview:bottomImageView];
    [self.view addSubview:view];
    

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
