//
//  XcodeBoostFoundation.h
//  XcodeBoost
//
//  Created by Michaël Fortin on 2014-03-21.
//  Copyright (c) 2014 Michaël Fortin. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^Block)();

BOOL MFRangeOverlaps(NSRange range1, NSRange range2);