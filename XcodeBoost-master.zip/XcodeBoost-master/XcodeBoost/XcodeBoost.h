//
//  XcodeBoost.h
//  XcodeBoost
//
//  Created by Michaël Fortin on 2014-03-14.
//  Copyright (c) 2014 Michaël Fortin. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface XcodeBoost : NSObject

@end