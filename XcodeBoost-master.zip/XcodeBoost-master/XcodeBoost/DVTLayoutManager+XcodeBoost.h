//
//  DVTLayoutManager+XcodeBoost.h
//  XcodeBoost
//
//  Created by Michaël Fortin on 2014-05-21.
//  Copyright (c) 2014 Michaël Fortin. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DVTKit.h"

@interface DVTLayoutManager (XcodeBoost)

@end