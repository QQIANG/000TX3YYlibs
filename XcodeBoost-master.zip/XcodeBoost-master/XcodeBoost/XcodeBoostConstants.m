//
//  XcodeBoostConstants.m
//  XcodeBoost
//
//  Created by Michaël Fortin on 2014-05-22.
//  Copyright (c) 2014 Michaël Fortin. All rights reserved.
//

#import "XcodeBoostConstants.h"

NSString *const XBHighlightColorAttributeName = @"XBHighlightColorAttributeName";

NSString *const XBHighlightColor1Key = @"XBHighlightColor1";
NSString *const XBHighlightColor2Key = @"XBHighlightColor2";
NSString *const XBHighlightColor3Key = @"XBHighlightColor3";
NSString *const XBHighlightColor4Key = @"XBHighlightColor4";