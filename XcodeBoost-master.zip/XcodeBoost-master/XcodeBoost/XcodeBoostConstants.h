//
//  XcodeBoostConstants.h
//  XcodeBoost
//
//  Created by Michaël Fortin on 2014-05-22.
//  Copyright (c) 2014 Michaël Fortin. All rights reserved.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString *const XBHighlightColorAttributeName;

FOUNDATION_EXPORT NSString *const XBHighlightColor1Key;
FOUNDATION_EXPORT NSString *const XBHighlightColor2Key;
FOUNDATION_EXPORT NSString *const XBHighlightColor3Key;
FOUNDATION_EXPORT NSString *const XBHighlightColor4Key;