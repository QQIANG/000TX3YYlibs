//
//  MFPluginController.h
//  XcodeBoost
//
//  Created by Michaël Fortin on 2014-03-14.
//  Copyright (c) 2014 Michaël Fortin. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface MFPluginController : NSObject

- (id)initWithPluginBundle:(NSBundle *)pluginBundle;

@end