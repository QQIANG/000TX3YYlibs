//
//  JNYJLabel.m
//  RollLabel
//
//  Created by zhouxl on 12-11-2.
//  Copyright (c) 2012年 zhouxl. All rights reserved.
//


#import "JNYJLabel.h"

#ifdef __IPHONE_7_0
#   define IsRuningIOS7    YES
#else
#   define IsRuningIOS7    NO
#endif

@implementation JNYJLabel
@synthesize rollDelegate;

- (id)initWithFrame:(CGRect)frame Withsize:(CGSize)size
{
    self = [super initWithFrame:frame];
    if (self) {
        self.showsVerticalScrollIndicator   = NO;
        self.showsHorizontalScrollIndicator = NO;//水平滚动条
//        self.bounces = NO;
        self.contentSize = size;//滚动大小
        self.backgroundColor = [UIColor clearColor];
        
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTap:)];
        tapGesture.numberOfTapsRequired = 1;
        
        // prevents the scroll view from swallowing up the touch event of child buttons
        tapGesture.cancelsTouchesInView = NO;
        [self addGestureRecognizer:tapGesture];
        [tapGesture release];
        
    }
    return self;
}
+ (void)JNYJLabelTitle:(NSString *)title color:(UIColor *)color font:(UIFont *)font
			 superView:(UIView *)superView frame:(CGRect)rect
{
	[self JNYJLabelTitle:title color:color font:font
			   superView:superView frame:rect
				delegate:nil tag:ROLL_VIEW_TAG];
}

+ (void)JNYJLabelTitle:(NSString *)title color:(UIColor *)color font:(UIFont *)font
			 superView:(UIView *)superView frame:(CGRect)rect
			  delegate:(id<JNYJLabelDelegate>)delegate
{
	[self JNYJLabelTitle:title color:color font:font
			   superView:superView frame:rect
				delegate:delegate tag:ROLL_VIEW_TAG];
}

+ (CGSize)JNYJLabelTitle:(NSString *)title color:(UIColor *)color font:(UIFont *)font
			 superView:(UIView *)superView frame:(CGRect)rect
			  delegate:(id<JNYJLabelDelegate>)delegate
				   tag:(NSInteger)tag
{
    //文字大小，设置label的大小和uiscroll的大小
    CGSize size;
    CGSize maximumSize = CGSizeMake(9999, 40);
	if (IsRuningIOS7) {
		NSDictionary *attribute = [NSDictionary dictionaryWithObjectsAndKeys:font,NSFontAttributeName, nil];
		CGRect rect_size = [title boundingRectWithSize:maximumSize
												options:NSStringDrawingUsesFontLeading
											 attributes:attribute context:nil];

		size = rect_size.size;
	}else{
		size = [title sizeWithFont:font
						 constrainedToSize:maximumSize
							 lineBreakMode:NSLineBreakByWordWrapping];
	}
    CGRect frame = CGRectMake(0, 0, size.width, rect.size.height);
    JNYJLabel *roll = [[JNYJLabel alloc]initWithFrame:rect Withsize:size];
    roll.backgroundColor = [UIColor clearColor];
    UILabel *label = [[UILabel alloc]initWithFrame:frame];
    label.text = title;
    label.font = font;
    label.textColor = color;
    label.backgroundColor = [UIColor clearColor];
    label.tag = ROLL_LABEL_TAG;
    label.adjustsFontSizeToFitWidth = NO;
    [roll addSubview:label];
    [label release];

    roll.rollDelegate = delegate;

    [superView addSubview:roll];
    roll.tag = tag;
    [roll release];

	return size;
}

+ (UILabel *)JNYJLabelAttributeText:(NSString *)text
							  color:(UIColor *)color
							   font:(UIFont *)font
						  superView:(UIView *)superView frame:(CGRect)rect
						   delegate:(id<JNYJLabelDelegate>)delegate
								tag:(NSInteger)tag
{
	return nil;
}
+ (CGSize)JNYJLabelTitle:(NSString *)title attributedText:(NSMutableAttributedString *)text
				   color:(UIColor *)color
					font:(UIFont *)font
			   superView:(UIView *)superView frame:(CGRect)rect
				delegate:(id<JNYJLabelDelegate>)delegate
					 tag:(NSInteger)tag
{
    //文字大小，设置label的大小和uiscroll的大小
    CGSize size;
    CGSize maximumSize = CGSizeMake(9999, 40);
	if (IsRuningIOS7) {
		NSDictionary *attribute = [NSDictionary dictionaryWithObjectsAndKeys:font,NSFontAttributeName, nil];
		CGRect rect_size = [title boundingRectWithSize:maximumSize
											   options:NSStringDrawingUsesFontLeading
											attributes:attribute context:nil];

		size = rect_size.size;
	}else{
		size = [title sizeWithFont:font
				 constrainedToSize:maximumSize
					 lineBreakMode:NSLineBreakByWordWrapping];
	}
    CGRect frame = CGRectMake(0, 0, size.width, rect.size.height);
    JNYJLabel *roll = [[JNYJLabel alloc]initWithFrame:rect Withsize:size];
    roll.backgroundColor = [UIColor clearColor];
    UILabel *label = [[UILabel alloc]initWithFrame:frame];
	//
    [label setText:title];
	//
    label.font = font;
    [label setTextColor:color];
    label.backgroundColor = [UIColor clearColor];
    label.tag = ROLL_LABEL_TAG;
    label.adjustsFontSizeToFitWidth = NO;
	//
    [label setAttributedText:text];
	//
    [roll addSubview:label];
    [label release];

    roll.rollDelegate = delegate;

    [superView addSubview:roll];
    roll.tag = tag;
    [roll release];

	return size;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)singleTap:(id)sender
{
    NSLog(@"JNYJLabel Single Tap.");
    
    // You need use the delegate to notice the single tap on the scroll view's superview.
    if ([self.rollDelegate respondsToSelector:@selector(JNYJLabelTapped:)]) {
        [self.rollDelegate JNYJLabelTapped:self];
    }
}


- (void)dealloc
{
    self.rollDelegate = nil;
    
    [super dealloc];
}
@end
