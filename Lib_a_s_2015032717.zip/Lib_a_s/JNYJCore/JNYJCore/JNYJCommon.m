//
//  JNYJCommon.m
//  QiQiao
//
//  Created by William on 7/3/15.
//  Copyright (c) 2015 zhggp. All rights reserved.
//

#import "JNYJCommon.h"

@implementation JNYJCommon

+(float)widthScreen{
    return [[UIScreen mainScreen]bounds].size.width;
//    return 320.0f;
}
+(UIFont *)fontNameSize:(CGFloat)size{
    return [UIFont fontWithName:@"Helvetica" size:size];
}

#pragma mark NSUserDefaults
+(BOOL)isSetedUserDefaultWithKey:(NSString *)key{
    
    NSString *autocity = [[NSUserDefaults standardUserDefaults] objectForKey:key];
    
    BOOL boolIsSeted = NO;
    
    if (autocity || [autocity isEqualToString:@""]) {
        if ([autocity isEqualToString:@"9527"]) {
            boolIsSeted = YES;
        }
        else {
            boolIsSeted = NO;
        }
    }
    //
    [[NSUserDefaults standardUserDefaults] setObject:@"9527" forKey:key];
    //
    return boolIsSeted;
}
+(void)setUserDefaultValue:(NSString *)value Key:(NSString *)key{
    [[NSUserDefaults standardUserDefaults] setObject:value forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
+(NSString *)userDefaultValueWithKey:(NSString *)key{
    
    NSString *paramStringValueForKey = [[NSUserDefaults standardUserDefaults] objectForKey:key];
    return paramStringValueForKey;
}
+(void)setUserDefaultValue_double:(double)value Key:(NSString *)key{
    [[NSUserDefaults standardUserDefaults] setDouble:value forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
+(double)userDefaultValue_double_WithKey:(NSString *)key{
    double paramStringValueForKey = [[NSUserDefaults standardUserDefaults] doubleForKey:key];
    return paramStringValueForKey;
}
+(BOOL) isFirstSetedKey:(NSString *)key{
    if ([self isSetedUserDefaultWithKey:key]) {
        return NO;
    }else{
        return YES;
    }
}

@end
#pragma mark Convert view rect

@implementation UIView (CenterViewInScrollView)
-(void)autoDisplayViewInScrollView:(UIScrollView *)scrollView{
    
    //    UITextField *textField_ =  (UITextField *)self;
    //    CGRect rect_t = textField_.frame;
    //    CGRect rect_s = scrollView.frame;
    //    CGFloat float_height_offset  = (rect_s.size.height/2.0);
    //    CGPoint point_t = [textField_ convertPoint:rect_t.origin toView:scrollView];
    //    CGPoint point_offset;
    //    if (point_t.y > float_height_offset) {
    //        point_offset = CGPointMake(0, (point_t.y-float_height_offset));
    //        [scrollView setContentOffset:point_offset animated:YES];
    //    }else{
    //        [scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    //    }
}
-(void)centerViewInScrollView:(UIScrollView *)scrollView{
    
    UIView *view_ =  (UIView *)self;
    UIView *view_superView_ = [view_ superview];
    //
    CGRect rect_t = view_.frame;
    CGRect rect_s = scrollView.frame;
    //
    CGFloat float_height_center  = (rect_s.size.height/2.0);
    
    //Convert view rect, need make sure this conditions
    if (view_superView_ && view_superView_ != scrollView) {
        //
        CGRect rect_convert = [view_superView_ convertRect:rect_t toView:scrollView];
        CGPoint point_center;
        //Assert it, who need to auto move to the center
        if (float_height_center>=rect_convert.origin.y) {//No need
            point_center = CGPointMake(0, 0);
            [scrollView setContentOffset:point_center animated:YES];
        }else{//Need
            //Counting off set point.y for view
            CGFloat float_center_offset = rect_convert.origin.y-float_height_center+(rect_t.size.height/2.0);
            point_center = CGPointMake(0, float_center_offset);
            [scrollView setContentOffset:point_center animated:YES];
        }
    }else{
        CGPoint point_center;
        //Assert it, who need to auto move to the center
        if (float_height_center>=rect_t.origin.y) {//No need
            point_center = CGPointMake(0, 0);
            [scrollView setContentOffset:point_center animated:YES];
        }else{//Need
            //Counting off set point.y for view
            CGFloat float_center_offset = rect_t.origin.y-float_height_center+(rect_t.size.height/2.0);
            point_center = CGPointMake(0, float_center_offset);
            [scrollView setContentOffset:point_center animated:YES];
        }
    }
}
@end
