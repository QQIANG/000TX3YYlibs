//
//  JNYJDashLine.m
//  JNYJCore
//
//  Created by William on 14-5-10.
//  Copyright (c) 2014年 JNYJ. All rights reserved.
//

#import "JNYJDashLine.h"

@implementation JNYJDashLine

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
		[self setBackgroundColor:[UIColor clearColor]];
    }
    return self;
}
-(void)configureLine{

	UIImageView *imageView1 = [[UIImageView alloc]initWithFrame:CGRectMake(0,0,self.frame.size.width,self.float_dash_line_thickness)];
	[self addSubview:imageView1];
	[imageView1 setBackgroundColor:[UIColor clearColor]];


	UIGraphicsBeginImageContext(imageView1.frame.size);   //开始画线
	[imageView1.image drawInRect:CGRectMake(0, 0, imageView1.frame.size.width, imageView1.frame.size.height)];
	CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);  //设置线条终点形状


	CGFloat lengths[] = {self.float_dash_width_line,self.float_dash_width_line_clear};
	CGContextRef line = UIGraphicsGetCurrentContext();
	CGContextSetStrokeColorWithColor(line, (self.color_dash_line).CGColor);

	CGContextSetLineDash(line, 0, lengths, 2);  //画虚线
	CGContextMoveToPoint(line, 0.0, self.float_dash_line_thickness);    //开始画线
	CGContextAddLineToPoint(line, self.frame.size.width, self.float_dash_line_thickness);
	CGContextStrokePath(line);

	imageView1.image = UIGraphicsGetImageFromCurrentImageContext();

}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
