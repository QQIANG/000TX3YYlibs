//
//  AddressReverseGeoder.h
//  ITC4Hotel
//
//  Created by William.zhou on 10-12-16.
//  Copyright 2010 XinYiSoft.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
@class Location;

@interface AddressReverseGeoder :	NSObject<MKReverseGeocoderDelegate> {
	Location *locationInfo;
	id target;
	SEL callBack;
}

@property(nonatomic, retain) Location *locationInfo;
@property(nonatomic, assign) id target;
@property(nonatomic, assign) SEL callBack;

- (void)startedReverseGeoderWithLatitude:(double)latitude longitude:(double)longitude; 

@end


@interface Location : NSObject{
	
	double latitude;
	double longitude;
	NSString *locationName;
}

@property (nonatomic, assign) double latitude;
@property (nonatomic, assign) double longitude;
@property (nonatomic, retain) NSString *locationName;
@end