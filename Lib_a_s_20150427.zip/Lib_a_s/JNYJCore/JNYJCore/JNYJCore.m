//
//  JNYJCore.m
//  JNYJCore
//
//  Created by William on 14-5-2.
//  Copyright (c) 2014年 JNYJ. All rights reserved.
//

#import "JNYJCore.h"

//#error Need build twice, see blow thanks.
#warning Build with Run Script:Need build twice!! (1-Build Simulator: Failed, and 2- Build Device, Succeed. GO TO .a FOLDER find Release-universal Folder to get OUR .a file)
//
#warning Need check ---> You additionally need to add -all_load to the Other Linker Flags of the target which is using your static library.



@implementation JNYJCore

+(void)helloWord{
	NSLog(@"Welcome to JNYJCore wor---ld!");
}

+(void)showLog:(NSString *)formatstring, ...{
    if (JNYJLogType == LogType_None) {
        return;
    }else if (JNYJLogType == LogType_API) {
    }else{
    }
    va_list arglist;
    if (!formatstring) return;
    va_start(arglist, formatstring);
    NSString *outstring = [[NSString alloc] initWithFormat:formatstring arguments:arglist];
    va_end(arglist);
    NSLog(@"===---->--->-->->: %@",outstring);
}
#pragma mark Private

-(NSString *)description{
	NSString *string_ = [super description];
	return [NSString stringWithFormat:@"-->Super:%@-->%@",string_,@"Welcome to JNYJCore wor---ld!"];
}
@end
