//
//  Created by William on 2/2/10.
//  Copyright (c) 2010 JNYJ. All rights reserved.
//
@interface JNYJUUID : NSObject

+(NSString*) UUID;

@end
