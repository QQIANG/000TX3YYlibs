//
//  Created by William on 2/2/10.
//  Copyright (c) 2010 JNYJ. All rights reserved.
//
#define JNYJ_UIFont(s) [UIFont fontWithName:@"Helvetica" size:s]
#define JNYJ_UIFontBold(s) [UIFont fontWithName:@"Helvetica-Bold" size:s]