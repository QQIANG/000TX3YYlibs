//
//  JNYJThirdCore.m
//  JNYJThirdCore
//
//  Created by William on 14-5-8.
//  Copyright (c) 2014年 JNYJ. All rights reserved.
//

#import "JNYJThirdCore.h"

@implementation JNYJThirdCore

@end
