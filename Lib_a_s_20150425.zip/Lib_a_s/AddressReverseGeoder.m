    //
//  AddressReverseGeoder.m
//  ITC4Hotel
//
//  Created by William.zhou on 10-12-16.
//  Copyright 2010 XinYiSoft.com. All rights reserved.
//

#import "AddressReverseGeoder.h"

@implementation AddressReverseGeoder
@synthesize locationInfo;
@synthesize target;
@synthesize callBack;

- (void)startedReverseGeoderWithLatitude:(double)latitude longitude:(double)longitude{
	CLLocationCoordinate2D coordinate2D;
	coordinate2D.longitude = longitude;
	coordinate2D.latitude = latitude;
	//
	if (self.locationInfo == nil) {
		self.locationInfo = [[[Location alloc] init] autorelease];
	}
	self.locationInfo.latitude = latitude;
	self.locationInfo.longitude = longitude;
	//
	MKReverseGeocoder *geoCoder = [[MKReverseGeocoder alloc] initWithCoordinate:coordinate2D];
	geoCoder.delegate = self;
	[geoCoder start];
}

#pragma mark -
#pragma mark MKReverseGeocoderDelegate methods

- (void)reverseGeocoder:(MKReverseGeocoder *)geocoder didFindPlacemark:(MKPlacemark *)placemark {
	NSLog(@"reverse finished...");
	NSLog(@"country:%@",placemark.country);
	NSLog(@"countryCode:%@",placemark.countryCode);
	NSLog(@"locality:%@",placemark.locality);
	NSLog(@"subLocality:%@",placemark.subLocality);
	NSLog(@"postalCode:%@",placemark.postalCode);
	NSLog(@"subThoroughfare:%@",placemark.subThoroughfare);
	NSLog(@"thoroughfare:%@",placemark.thoroughfare);
	NSLog(@"administrativeArea:%@",placemark.administrativeArea);
	
	self.locationInfo.locationName = [NSString stringWithFormat:@"%@ %@,%@ %@,%@", 
									  placemark.country,
									  placemark.administrativeArea,
									  placemark.locality,
									  placemark.subLocality,
									  placemark.thoroughfare];
	
	NSLog(@"administrativeArea:%@",self.locationInfo.locationName);
	
	[self.target performSelector:self.callBack withObject:@"0"];
}

- (void)reverseGeocoder:(MKReverseGeocoder *)geocoder didFailWithError:(NSError *)error {
	NSLog(@"error %@" , error);
	[self.target performSelector:self.callBack withObject:@"1"];
}

- (void)dealloc {
    [super dealloc];
	[locationInfo release];
}
@end

@implementation Location
@synthesize latitude,longitude,locationName;

-(void) dealloc{
	
	[super dealloc];
	[locationName release];
}
@end
