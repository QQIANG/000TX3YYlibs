//
//  JNYJThirdCore.h
//  JNYJThirdCore
//
//  Created by William on 14-5-8.
//  Copyright (c) 2014年 JNYJ. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "JNYJReachability.h"

#define Message_network_problem		@"当前无网络，请检查网络设置。"

@interface JNYJThirdCore : NSObject

@end
