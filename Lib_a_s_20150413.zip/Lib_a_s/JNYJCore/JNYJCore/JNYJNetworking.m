//
//  InterfaceCaller.m
//  GKIC
//
//  Created by han on 11-8-18.
//  Copyright 2011年 Comcsoft. All rights reserved.
//

#import "JNYJNetworking.h"

@interface JNYJNetworking ()
- (void)dealWithResponse:(NSString *)responseString;
@end

@implementation JNYJNetworking
@synthesize delegate_networking;
@synthesize receivedData;

#pragma mark --
#pragma mark Do log
+(void)doLogForTemp:(NSString *)formatstring, ...{
    return;
	va_list arglist;
	if (!formatstring) return;
	va_start(arglist, formatstring);
	NSString *outstring = [[[NSString alloc] initWithFormat:formatstring arguments:arglist] autorelease];
	va_end(arglist);
    NSLog(@"===---->--->-->->: %@",outstring);
}
#pragma mark - call
+ (JNYJNetworking *)RequestService:(NSString *)serviceURLPath andDelegate:(id)delegate
{
    //init InterfaceCaller
    JNYJNetworking *mainInterfaceCaller = [[JNYJNetworking alloc] init];
    [mainInterfaceCaller setDelegate_networking:delegate];
    NSURL *serviceURL = [[NSURL alloc] initWithString:serviceURLPath];
    //
    NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:serviceURL cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:10.0];
    [theRequest addValue:@"text/json" forHTTPHeaderField:@"Content-Type"];
    [theRequest setHTTPMethod:@"POST"];
    [serviceURL release];
    
    NSURLConnection *theConnection = [[[NSURLConnection alloc] initWithRequest:theRequest delegate:mainInterfaceCaller] autorelease];
    
    if(theConnection) {
        [JNYJNetworking doLogForTemp: @"theConnection called"];
    }else {
        [JNYJNetworking doLogForTemp: @"theConnection is NULL"];
        if (delegate) [delegate InterfaceCaller:mainInterfaceCaller EndWithData:nil];
	}
    
    return mainInterfaceCaller;
}

- (void)dealloc
{
    [super dealloc];
}

#pragma mark - connection delegate
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    self.receivedData = [NSMutableData data];
}

- (void)connection:(NSURLConnection *)aConn didReceiveData:(NSData *)data {
    [self.receivedData appendData:data];
}

- (void)connection:(NSURLConnection *)aConn didFailWithError:(NSError *)error {
    [JNYJNetworking doLogForTemp: @"connection error: %@", [error localizedDescription]];
    [receivedData release], receivedData = nil;
    if (delegate_networking) [delegate_networking InterfaceCaller:self EndWithData:nil];
    [self release], self = nil;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)aConn {
    
    //response string
    NSString *results = [[NSString alloc] initWithBytes:[self.receivedData bytes] length:[self.receivedData length] encoding:NSUTF8StringEncoding];
    [JNYJNetworking doLogForTemp: @"\nconnectionDidFinishLoading -- \nwholeResults:(\n%@\n)", results];
    [receivedData release], receivedData = nil;
    [self dealWithResponse:results];
    [results release], results = nil;
    [self release], self = nil;
}

- (void)dealWithResponse:(NSString *)responseString
{
    NSDictionary *dictobj = [JNYJNetworking dic_JSON:responseString];
    [JNYJNetworking doLogForTemp:@"Result:(\n%@)",dictobj];
    if (delegate_networking) [delegate_networking InterfaceCaller:self EndWithData:dictobj];
}

#pragma mark JSON
+(NSDictionary *)dic_JSON:(NSString *)json{

	NSError *error;

	NSDictionary *dic_JSON =
	[NSJSONSerialization JSONObjectWithData: [json dataUsingEncoding:NSUTF8StringEncoding]
									options: NSJSONReadingMutableContainers
									  error: &error];
	NSDictionary *dic_return = [NSDictionary dictionaryWithObjectsAndKeys:dic_JSON,@"dic_return_20140424", nil];
	return dic_return;

}
@end
