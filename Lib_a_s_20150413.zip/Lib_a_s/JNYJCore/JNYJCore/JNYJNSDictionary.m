//
//  JNYJNSDictionary.m
//  JNYJCore
//
//  Created by cotson on 14-7-2.
//  Copyright (c) 2014年 JNYJ. All rights reserved.
//

#import "JNYJNSDictionary.h"

@implementation NSDictionary (JNYJ_JSON)

+(NSString *)JSON_dic:(NSDictionary *)dic{
    
    NSError *error;
    NSString *string_json= @"";
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic
                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                         error:&error];
    if (! jsonData) {
        NSLog(@"Got an error: %@", error);
    } else {
        string_json = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        string_json =  [[string_json componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]]
                        componentsJoinedByString:@""];
    }
    return string_json;
}
+(NSDictionary *)dic_JSON:(NSString *)json{
    
    NSError *error;
    
    NSDictionary *dic_JSON =
    [NSJSONSerialization JSONObjectWithData: [json dataUsingEncoding:NSUTF8StringEncoding]
                                    options: NSJSONReadingMutableContainers
                                      error: &error];
    NSDictionary *dic_return = [NSDictionary dictionaryWithObjectsAndKeys:dic_JSON,@"dic_return_20140424", nil];
    return dic_return;
    
}
@end


@implementation NSString (JNYJ_JSON)

+(NSString *)JSON_dic:(NSDictionary *)dic{
    
    NSError *error;
    NSString *string_json= @"";
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic
                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                         error:&error];
    if (! jsonData) {
        NSLog(@"Got an error: %@", error);
    } else {
        string_json = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        string_json =  [[string_json componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]]
                        componentsJoinedByString:@""];
    }
    return string_json;
}
+(NSDictionary *)dic_JSON:(NSString *)json{
    
    NSError *error;
    
    NSDictionary *dic_JSON =
    [NSJSONSerialization JSONObjectWithData: [json dataUsingEncoding:NSUTF8StringEncoding]
                                    options: NSJSONReadingMutableContainers
                                      error: &error];
    NSDictionary *dic_return = [NSDictionary dictionaryWithObjectsAndKeys:dic_JSON,@"dic_return_20140424", nil];
    return dic_return;
    
}
@end

