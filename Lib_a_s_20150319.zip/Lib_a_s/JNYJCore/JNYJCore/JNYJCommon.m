//
//  JNYJCommon.m
//  QiQiao
//
//  Created by William on 7/3/15.
//  Copyright (c) 2015 zhggp. All rights reserved.
//

#import "JNYJCommon.h"

@implementation JNYJCommon

+(float)widthScreen{
    return [[UIScreen mainScreen]bounds].size.width;
//    return 320.0f;
}
+(UIFont *)fontNameSize:(CGFloat)size{
    return [UIFont fontWithName:@"Helvetica" size:size];
}

#pragma mark NSUserDefaults
+(BOOL)isSetedUserDefaultWithKey:(NSString *)key{
    
    NSString *autocity = [[NSUserDefaults standardUserDefaults] objectForKey:key];
    
    BOOL boolIsSeted = NO;
    
    if (autocity || [autocity isEqualToString:@""]) {
        if ([autocity isEqualToString:@"9527"]) {
            boolIsSeted = YES;
        }
        else {
            boolIsSeted = NO;
        }
    }
    //
    [[NSUserDefaults standardUserDefaults] setObject:@"9527" forKey:key];
    //
    return boolIsSeted;
}
+(void)setUserDefaultValue:(NSString *)value Key:(NSString *)key{
    [[NSUserDefaults standardUserDefaults] setObject:value forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
+(NSString *)userDefaultValueWithKey:(NSString *)key{
    
    NSString *paramStringValueForKey = [[NSUserDefaults standardUserDefaults] objectForKey:key];
    return paramStringValueForKey;
}
+(void)setUserDefaultValue_double:(double)value Key:(NSString *)key{
    [[NSUserDefaults standardUserDefaults] setDouble:value forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
+(double)userDefaultValue_double_WithKey:(NSString *)key{
    double paramStringValueForKey = [[NSUserDefaults standardUserDefaults] doubleForKey:key];
    return paramStringValueForKey;
}
+(BOOL) isFirstSetedKey:(NSString *)key{
    if ([self isSetedUserDefaultWithKey:key]) {
        return NO;
    }else{
        return YES;
    }
}
@end
