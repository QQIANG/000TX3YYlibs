//
//  JNYJUUID.h
//  JNYJCore
//
//  Created by cotson on 14-6-9.
//  Copyright (c) 2014年 JNYJ. All rights reserved.
//

@interface JNYJUUID : NSObject

+(NSString*) UUID;

@end
