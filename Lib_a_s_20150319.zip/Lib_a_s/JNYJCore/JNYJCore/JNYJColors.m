//
//  Colors.m
//  Colors
//
//  Created by William on 14-5-2.
//  Copyright (c) 2014年 JNYJCore. All rights reserved.
//

#import "JNYJColors.h"
#import "NSAttributedString+Attributes.h"



#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]



@implementation JNYJColors
+(JNYJColors *)shareJNYJCoreColors{

    static JNYJColors *_shareColors = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _shareColors = [[JNYJColors alloc] init];
    });

    return _shareColors;
}


+(void)setKeywordsArray:(NSArray *)array
			   withColor:(UIColor *)color
	  inAttributedString:(NSMutableAttributedString*) mutableAttributedString
{
    for (int i = 0; i<[array count]; i++) {
        NSString *matchString = [NSString stringWithFormat:@"%@",[array objectAtIndex:i]];//(\\W|^)%@(\\W|$) | @" %@ "
        NSRegularExpression *exp = [NSRegularExpression regularExpressionWithPattern:matchString
                                                                             options:NSRegularExpressionDotMatchesLineSeparators
                                                                               error:nil];
        matchString = nil;
        NSArray *textArr = [exp matchesInString:[mutableAttributedString string] options:0 range:NSMakeRange(0, [[mutableAttributedString string] length])];
        exp =nil;
        for (NSTextCheckingResult *result in textArr) {
            NSRange realRange = result.range;
            [mutableAttributedString setTextColor:color range:realRange];//result.range];
        }

        textArr = nil;//qxj


    }
}

+(NSMutableAttributedString *)attributedString:(NSString *)value
									  keywords:(NSArray *)keywords
										 color:(UIColor *)color{
	//
	NSMutableAttributedString *string_mu = [NSMutableAttributedString attributedStringWithString:value];

	[self setKeywordsArray:[NSArray arrayWithArray:keywords]
				 withColor:color
		inAttributedString:string_mu];
	return string_mu;
	//
}

+(void)setKeywordsArray:(NSArray *)array
			  withColor:(UIColor *)color
	 inAttributedString:(NSMutableAttributedString*) mutableAttributedString
				   font:(UIFont *)font
{
	[mutableAttributedString setFont:font];
    for (int i = 0; i<[array count]; i++) {
        NSString *matchString = [NSString stringWithFormat:@"%@",[array objectAtIndex:i]];//(\\W|^)%@(\\W|$) | @" %@ "
        NSRegularExpression *exp = [NSRegularExpression regularExpressionWithPattern:matchString
                                                                             options:NSRegularExpressionDotMatchesLineSeparators
                                                                               error:nil];
        matchString = nil;
        NSArray *textArr = [exp matchesInString:[mutableAttributedString string] options:0 range:NSMakeRange(0, [[mutableAttributedString string] length])];
        exp =nil;
        for (NSTextCheckingResult *result in textArr) {
            NSRange realRange = result.range;
            [mutableAttributedString setTextColor:color range:realRange];//result.range];
        }

        textArr = nil;//qxj


    }
}

+(NSMutableAttributedString *)attributedString:(NSString *)value
									  keywords:(NSArray *)keywords
										 color:(UIColor *)color
										  font:(UIFont *)font{
	//
	NSMutableAttributedString *string_mu = [NSMutableAttributedString attributedStringWithString:value];

	[self setKeywordsArray:[NSArray arrayWithArray:keywords]
				 withColor:color
		inAttributedString:string_mu
					  font:font];
	return string_mu;
	//
}

+(NSMutableAttributedString *)attributedString:(NSString *)value
									  keywords_groups:(NSArray *)keywords
										 color_groups:(NSArray *)colors
										  font_groups:(NSArray *)fonts{
	//
	NSMutableAttributedString *string_mu = [NSMutableAttributedString attributedStringWithString:value];
	for (int i=0; i<[keywords count]; i++) {
		NSArray *array_ = [keywords objectAtIndex:i];
		if ([colors count]>i) {
			if ([fonts count] == 1) {
				[self setKeywordsArray:array_
							 withColor:[colors objectAtIndex:i]
					inAttributedString:string_mu
								  font:[fonts objectAtIndex:0]];
			}else if ([fonts count]>i) {
				[self setKeywordsArray:array_
							 withColor:[colors objectAtIndex:i]
					inAttributedString:string_mu
								  font:[fonts objectAtIndex:i]];
			}else{
				[self setKeywordsArray:array_
							 withColor:[colors objectAtIndex:i]
					inAttributedString:string_mu];
			}
		}
	}
	return string_mu;
	//
}
@end


@implementation UIColor (extension)

+ (UIColor*) colorWithHexString:(NSString *)hexStr{
    return UIColorFromRGB([UIColor intFromHexString:hexStr]);
}
+ (UIColor*) colorWithHex:(NSInteger)hexValue alpha:(CGFloat)alphaValue
{
    return [UIColor colorWithRed:((float)((hexValue & 0xFF0000) >> 16))/255.0
                           green:((float)((hexValue & 0xFF00) >> 8))/255.0
                            blue:((float)(hexValue & 0xFF))/255.0 alpha:alphaValue];
}

+ (UIColor*) colorWithHex:(NSInteger)hexValue
{
    return [UIColor colorWithHex:hexValue alpha:1.0];
}

+ (NSString *) hexFromUIColor: (UIColor*) color {
    if (CGColorGetNumberOfComponents(color.CGColor) < 4) {
        const CGFloat *components = CGColorGetComponents(color.CGColor);
        color = [UIColor colorWithRed:components[0]
                                green:components[0]
                                 blue:components[0]
                                alpha:components[1]];
    }
    
    if (CGColorSpaceGetModel(CGColorGetColorSpace(color.CGColor)) != kCGColorSpaceModelRGB) {
        return [NSString stringWithFormat:@"#FFFFFF"];
    }
    
    return [NSString stringWithFormat:@"#%x%x%x", (int)((CGColorGetComponents(color.CGColor))[0]*255.0),
            (int)((CGColorGetComponents(color.CGColor))[1]*255.0),
            (int)((CGColorGetComponents(color.CGColor))[2]*255.0)];
}
+ (unsigned int)intFromHexString:(NSString *)hexStr
{
    unsigned int hexInt = 0;
    
    // Create scanner
    NSScanner *scanner = [NSScanner scannerWithString:hexStr];
    
    // Tell scanner to skip the # character
    [scanner setCharactersToBeSkipped:[NSCharacterSet characterSetWithCharactersInString:@"#"]];
    
    // Scan hex value
    [scanner scanHexInt:&hexInt];
    
    return hexInt;
}
@end
