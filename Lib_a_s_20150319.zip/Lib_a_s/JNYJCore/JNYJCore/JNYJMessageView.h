//
//  JNYJMessageView.h
//  QiQiao
//
//  Created by William on 9/3/15.
//  Copyright (c) 2015 zhggp. All rights reserved.
//
#define JNYJ_CGFloat_leftright_contents_space 4
#define JNYJ_Message_background_color [UIColor blackColor]
#define JNYJ_Message_title_color [UIColor whiteColor]
@interface JNYJMessageView : NSObject
+ (instancetype)sharedMessageView;
+(void)showMessage:(NSString *)message inView:(UIView *)view;
@end
