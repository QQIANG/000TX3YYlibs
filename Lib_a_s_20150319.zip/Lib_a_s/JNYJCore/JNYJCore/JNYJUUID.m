//
//  JNYJUUID.m
//  JNYJCore
//
//  Created by cotson on 14-6-9.
//  Copyright (c) 2014年 JNYJ. All rights reserved.
//

#import "JNYJUUID.h"

@implementation JNYJUUID

//iOS中获取UUID的代码如下:
+(NSString*) UUID {
    CFUUIDRef puuid = CFUUIDCreate( nil );
    CFStringRef uuidString = CFUUIDCreateString( nil, puuid );
    NSString * result = (NSString *)CFBridgingRelease(CFStringCreateCopy( NULL, uuidString));
    CFRelease(puuid);
    CFRelease(uuidString);
    return result;
}
@end
