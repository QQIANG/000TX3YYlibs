//
//  JNYJConstants.h
//  JNYJCore
//
//  Created by William on 11/3/15.
//  Copyright (c) 2015 JNYJ. All rights reserved.
//


#define JNYJ_UIFont(s) [UIFont fontWithName:@"Helvetica" size:s]
#define JNYJ_UIFontBold(s) [UIFont fontWithName:@"Helvetica-Bold" size:s]