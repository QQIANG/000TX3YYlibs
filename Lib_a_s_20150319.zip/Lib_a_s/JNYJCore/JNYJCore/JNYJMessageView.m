//
//  JNYJMessageView.m
//  QiQiao
//
//  Created by William on 9/3/15.
//  Copyright (c) 2015 zhggp. All rights reserved.
//

#import "JNYJMessageView.h"

@implementation JNYJMessageView

+ (instancetype)sharedMessageView{
    static JNYJMessageView *_sharedClient = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedClient = [[JNYJMessageView alloc] init];
    });
    
    return _sharedClient;
}

+(void)showMessage:(NSString *)message inView:(UIView *)view{
    //
    CGRect rect_ = view.frame;
    CGRect rect_s;
    UIView *view_contents = [[UIView alloc] initWithFrame:CGRectMake(0, 0, rect_.size.width, rect_.size.height/2.0)];
    [view addSubview:view_contents];
    [view_contents setBackgroundColor:[UIColor clearColor]];
    
    rect_ = view_contents.frame;
    UIView *view_ = [[UIView alloc] initWithFrame:CGRectMake(0, 0, rect_.size.width, rect_.size.height)];
    [view_contents addSubview:view_];
    [view_ setBackgroundColor:[UIColor clearColor]];
//    view_ setAlpha:0
    //
    UILabel *label_ = [[UILabel alloc] initWithFrame:CGRectMake((rect_.size.width-70)/2.0, 0,
                                                                70, 26)];
    [view_contents addSubview:label_];
    [label_ setText:message];
    [label_ setTextColor:JNYJ_Message_title_color];
    [label_ setFont:JNYJ_UIFont(14)];
    [label_ setTextAlignment:NSTextAlignmentCenter];
    [label_ setBackgroundColor:JNYJ_Message_background_color];
    label_.layer.masksToBounds = YES;
    label_.layer.cornerRadius = 6.0f;
    //
    [label_ setCenter:view_contents.center];
    [label_ setAlpha:0.98];
    //Label size
    CGSize maximumSize = CGSizeMake(9999, 40);
    NSDictionary *attribute = [NSDictionary dictionaryWithObjectsAndKeys:label_.font,NSFontAttributeName, nil];
    CGRect rect_size = [label_.text boundingRectWithSize:maximumSize
                                           options:NSStringDrawingUsesFontLeading
                                        attributes:attribute context:nil];
    rect_ = label_.frame;
    rect_s = view_contents.frame;
    rect_.size.width = rect_size.size.width+(JNYJ_CGFloat_leftright_contents_space*2);
    rect_.origin.x = (rect_s.size.width-rect_.size.width)/2.0;
    [label_ setFrame:rect_];
    //
    [UIView animateWithDuration:1.75 animations:^{
        [label_ setAlpha:1.0];
    } completion:^(BOOL isFinished){
        //
        [UIView animateWithDuration:0.325 animations:^{
            [label_ setAlpha:0.15];
        } completion:^(BOOL isFinished){
            [view_contents removeFromSuperview];
        }];
    }];
}
@end
