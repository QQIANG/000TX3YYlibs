//
//  XLFormTestCase.m
//  XLForm Tests
//
//  Created by Martin Barreto on 8/5/14.
//
//

#import "XLTestCase.h"

@implementation XLTestCase

@end
